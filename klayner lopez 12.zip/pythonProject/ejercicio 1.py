num1=int(input("ingrese un numero entero:"));
nun2=int(input("ingrese otro numero entero:"));
if num1 > nun2:
    mensaje="el numero mayor es:",num1,"el numero menor es:",nun2;
else:
    mensaje = "el numero mayor es:",nun2,"el numero menor es:",num1;
print(mensaje);S