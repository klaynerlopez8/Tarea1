num1=int(input("ingrese un numero entero:"));S
nun2=int(input("ingrese otro numero entero:"));
num3=int(input("ingrese otro numero entero:"))
total=num1+nun2+num3;
if total%7==0:
    mensaje="total si es multiplo de:",7
else:
    mensaje="total no es multiplo de:",7
print(mensaje);