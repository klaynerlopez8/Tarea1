num=int(input("ingrese un numero entero:"));
if num > 0:
    mensaje="es un numero positivo"
elif num == 0:
    mensaje = "es un numero neutro";
else:
    mensaje="es un numero negatvo";
print(mensaje);
S